

waxClass{"HomeViewController", UIViewController}


function homeItemViewAction(self, itemView)
    local num = itemView:item():tag()
    puts(num)

   if (num == 1100)
       self:adsJump()
   else if (num == 1200)
       self:mainPageController():goModule(MainTypeHotel)
end