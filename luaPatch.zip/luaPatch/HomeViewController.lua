

waxClass{"HomeViewController", UIViewController}


function homeItemViewAction(self, itemView)
    local num = itemView:item():tag()
    puts(num)
end